from setuptools import setup

setup(
    name='lab3',
    version='0.1',
    description='laboratory work № 3',
    author='Sokolov Ivan',
    packages=['lab_work'],
    scripts = ['run.py'],
)